import { useState, useEffect, useRef } from 'react';

// ─── ENGINEERING MINDSET ──────────────────────────────────────────────────────
const PRINCIPLES = [
  { num:'I',   text:'Build before I feel ready.',   sub:'Action creates clarity. Thinking too long is a trap.',         icon:'⚡' },
  { num:'II',  text:'Learn through execution.',     sub:'Building teaches what reading cannot.',                        icon:'⚙' },
  { num:'III', text:'Solve meaningful problems.',   sub:'Technology should serve people, not itself.',                  icon:'◎' },
  { num:'IV',  text:'UX matters as much as code.',  sub:"Code that doesn't serve users is incomplete code.",           icon:'◈' },
  { num:'V',   text:'Understand systems deeply.',   sub:'Surface knowledge creates fragile solutions.',                 icon:'◆' },
  { num:'VI',  text:'Consistency beats intensity.', sub:'1% better every day compounds into mastery.',                  icon:'◉' },
];

export const EngineeringMindset = () => (
  <section style={{ padding:'120px 40px', background:'var(--surface)' }}>
    <div style={{ maxWidth:1200, margin:'0 auto' }}>
      <div className="reveal-on-scroll" style={{ marginBottom:60 }}>
        <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:16 }}>
          <div style={{ width:32, height:1, background:'var(--accent2)' }}/>
          <span className="mono" style={{ fontSize:11, color:'var(--accent2)', letterSpacing:'.2em' }}>PRINCIPLES</span>
        </div>
        <h2 className="syne" style={{ fontSize:'clamp(36px,5vw,56px)', fontWeight:800, letterSpacing:'-.02em' }}>Engineering<br/><span style={{ color:'var(--text3)' }}>Mindset</span></h2>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))', gap:20 }}>
        {PRINCIPLES.map((p, i) => (
          <div key={i} className="reveal-on-scroll" data-hover
            style={{ transitionDelay:`${i*.1}s`, padding:32, borderRadius:16, border:'1px solid var(--border)', background:'var(--surface2)', position:'relative', overflow:'hidden', cursor:'default', transition:'border-color .3s,transform .3s' }}
            onMouseEnter={e => { e.currentTarget.style.borderColor='rgba(255,208,0,.3)'; e.currentTarget.style.transform='translateY(-4px)'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.transform='translateY(0)'; }}>
            <div style={{ position:'absolute', top:20, right:24 }}>
              <span className="syne" style={{ fontSize:32, fontWeight:800, color:'rgba(255,208,0,.06)' }}>{p.num}</span>
            </div>
            <div style={{ fontSize:24, marginBottom:16 }}>{p.icon}</div>
            <p className="syne" style={{ fontSize:17, fontWeight:700, marginBottom:8, lineHeight:1.4 }}>{p.text}</p>
            <p style={{ fontSize:13, color:'var(--text3)', lineHeight:1.6 }}>{p.sub}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

// ─── TECHNOLOGIES ─────────────────────────────────────────────────────────────
const TECHS = [
  { name:'C++',             cat:'Language',         glyph:'C++' },
  { name:'Data Structures', cat:'CS Fundamentals',  glyph:'DSA' },
  { name:'Algorithms',      cat:'CS Fundamentals',  glyph:'ALG' },
  { name:'React',           cat:'Framework',        glyph:'Re'  },
  { name:'JavaScript',      cat:'Language',         glyph:'JS'  },
  { name:'TypeScript',      cat:'Language',         glyph:'TS'  },
  { name:'HTML5',           cat:'Markup',           glyph:'<>'  },
  { name:'CSS3',            cat:'Styling',          glyph:'css' },
  { name:'Git',             cat:'Version Control',  glyph:'git' },
  { name:'Frontend Dev',    cat:'Domain',           glyph:'UI'  },
];

export const Technologies = () => (
  <section style={{ padding:'120px 40px', maxWidth:1200, margin:'0 auto' }}>
    <div className="reveal-on-scroll" style={{ marginBottom:60 }}>
      <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:16 }}>
        <div style={{ width:32, height:1, background:'var(--accent3)' }}/>
        <span className="mono" style={{ fontSize:11, color:'var(--accent3)', letterSpacing:'.2em' }}>EXPLORED</span>
      </div>
      <h2 className="syne" style={{ fontSize:'clamp(36px,5vw,56px)', fontWeight:800, letterSpacing:'-.02em' }}>Technologies &<br/><span style={{ color:'var(--text3)' }}>Concepts</span></h2>
    </div>
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:16 }}>
      {TECHS.map((t, i) => (
        <div key={i} className="reveal-on-scroll" data-hover
          style={{ transitionDelay:`${i*.05}s`, padding:24, borderRadius:14, border:'1px solid var(--border)', background:'var(--surface)', cursor:'default', transition:'border-color .3s,background .3s,transform .3s' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor='rgba(255,208,0,.3)'; e.currentTarget.style.background='var(--surface2)'; e.currentTarget.style.transform='translateY(-3px)'; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.background='var(--surface)'; e.currentTarget.style.transform='translateY(0)'; }}>
          <div className="syne" style={{ fontSize:28, fontWeight:800, color:'rgba(255,208,0,.14)', marginBottom:16, letterSpacing:'-.02em' }}>{t.glyph}</div>
          <div className="syne" style={{ fontSize:15, fontWeight:700, marginBottom:4 }}>{t.name}</div>
          <div className="mono" style={{ fontSize:10, color:'var(--text3)', letterSpacing:'.1em' }}>{t.cat}</div>
        </div>
      ))}
    </div>
  </section>
);

// ─── METRICS ─────────────────────────────────────────────────────────────────
const Counter = ({ target, suffix='' }) => {
  const [n, setN] = useState(0);
  const ref  = useRef(null);
  const done = useRef(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !done.current) {
        done.current = true;
        let s = 0;
        const step = ts => {
          if (!s) s = ts;
          const p = Math.min((ts - s) / 2000, 1);
          setN(Math.floor((1 - Math.pow(1 - p, 3)) * target));
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      }
    }, { threshold:.5 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target]);
  return <span ref={ref}>{n.toLocaleString()}{suffix}</span>;
};

const METRICS = [
  { v:800, s:'+', l:'Hours Learning',    sub:'Invested in growth'  },
  { v:300, s:'+', l:'Problems Solved',   sub:'DSA & algorithms'    },
  { v:40,  s:'+', l:'Concepts Explored', sub:'Across CS domains'   },
  { v:8,   s:'',  l:'Technologies',      sub:'Currently learning'  },
];

export const Metrics = () => (
  <section style={{ padding:'80px 40px', background:'var(--surface)', borderTop:'1px solid var(--border)', borderBottom:'1px solid var(--border)' }}>
    <div style={{ maxWidth:1200, margin:'0 auto', display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:40 }}>
      {METRICS.map((m, i) => (
        <div key={i} style={{ textAlign:'center', padding:20 }}>
          <div className="syne" style={{ fontSize:'clamp(40px,5vw,60px)', fontWeight:800, background:'linear-gradient(135deg,#ffd000,#ffaa00)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text', marginBottom:8 }}>
            <Counter target={m.v} suffix={m.s}/>
          </div>
          <div className="syne" style={{ fontSize:16, fontWeight:600, marginBottom:4 }}>{m.l}</div>
          <div className="mono" style={{ fontSize:11, color:'var(--text3)', letterSpacing:'.1em' }}>{m.sub}</div>
        </div>
      ))}
    </div>
  </section>
);

// ─── PHILOSOPHY ───────────────────────────────────────────────────────────────
export const Philosophy = () => (
  <section style={{ padding:'160px 40px', position:'relative', overflow:'hidden', textAlign:'center' }}>
    <div style={{ position:'absolute', inset:0, background:'linear-gradient(270deg,rgba(255,208,0,.05),rgba(255,170,0,.04),rgba(255,230,80,.03),rgba(255,208,0,.05))', backgroundSize:'400% 400%', animation:'aurora 12s ease infinite', pointerEvents:'none' }}/>
    <div style={{ position:'absolute', inset:0, backdropFilter:'blur(80px)', pointerEvents:'none' }}/>
    <div style={{ maxWidth:800, margin:'0 auto', position:'relative', zIndex:1 }}>
      <div className="reveal-on-scroll">
        <div style={{ width:48, height:1, background:'linear-gradient(to right,transparent,var(--accent))', margin:'0 auto 32px' }}/>
        <blockquote className="syne" style={{ fontSize:'clamp(24px,4vw,44px)', fontWeight:700, lineHeight:1.3, letterSpacing:'-.02em', marginBottom:32 }}>
          "Great software isn't just code.<br/>
          <span style={{ background:'linear-gradient(135deg,#ffd000,#ffaa00)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>
            It's understanding people,<br/>problems, and possibilities."
          </span>
        </blockquote>
        <div style={{ width:48, height:1, background:'linear-gradient(to left,transparent,var(--accent))', margin:'0 auto' }}/>
      </div>
    </div>
  </section>
);
