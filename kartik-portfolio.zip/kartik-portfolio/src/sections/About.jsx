const STAGES = [
  { num:'01', title:'Curiosity',          color:'#ffd000', year:'The Beginning', desc:'Started questioning how things work. Why does software behave this way? What makes a great product? Curiosity became the foundation.' },
  { num:'02', title:'Discovery',          color:'#ffaa00', year:'The Spark',      desc:'Discovered the world of technology — programming languages, systems, the internet. Every new concept opened another door worth exploring.' },
  { num:'03', title:'Learning to Build',  color:'#ffe566', year:'The Builder',    desc:'Moved from consuming to creating. Started with C++ and DSA, then frontend development. Learning through building is the fastest path.' },
  { num:'04', title:'Engineering Mindset',color:'#fff0a0', year:'Now',            desc:'Thinking in systems. Understanding products, user experience, and the why behind decisions. Developing taste and technical foundation simultaneously.' },
];

const About = () => (
  <section id="about" style={{ padding:'120px 40px', maxWidth:1200, margin:'0 auto' }}>
    <div className="reveal-on-scroll">
      <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:16 }}>
        <div style={{ width:32, height:1, background:'var(--accent)' }}/>
        <span className="mono" style={{ fontSize:11, color:'var(--accent)', letterSpacing:'.2em' }}>ORIGIN STORY</span>
      </div>
      <h2 className="syne" style={{ fontSize:'clamp(36px,5vw,56px)', fontWeight:800, marginBottom:80, letterSpacing:'-.02em' }}>
        The Journey<br/><span style={{ color:'var(--text3)' }}>So Far</span>
      </h2>
    </div>
    <div style={{ position:'relative' }}>
      <div style={{ position:'absolute', left:0, top:0, bottom:0, width:1, background:'linear-gradient(to bottom,var(--accent),var(--accent2),transparent)', opacity:.3 }}/>
      {STAGES.map((s, i) => (
        <div key={i} className="reveal-on-scroll" style={{ display:'flex', gap:40, paddingLeft:40, paddingBottom:60, position:'relative', transitionDelay:`${i*.15}s` }}>
          <div style={{ position:'absolute', left:-8, top:8, width:17, height:17, borderRadius:'50%', background:s.color, boxShadow:`0 0 18px ${s.color}`, border:'3px solid var(--bg)' }}/>
          <div style={{ flex:1 }}>
            <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:12 }}>
              <span className="mono" style={{ fontSize:11, color:'var(--text3)', letterSpacing:'.15em' }}>{s.num}</span>
              <span className="mono" style={{ fontSize:10, color:s.color, padding:'3px 10px', borderRadius:100, border:`1px solid ${s.color}30`, letterSpacing:'.1em' }}>{s.year}</span>
            </div>
            <h3 className="syne" style={{ fontSize:28, fontWeight:700, marginBottom:12, color:s.color }}>{s.title}</h3>
            <p style={{ color:'var(--text2)', lineHeight:1.8, maxWidth:480, fontSize:15 }}>{s.desc}</p>
          </div>
        </div>
      ))}
    </div>
  </section>
);

export default About;
