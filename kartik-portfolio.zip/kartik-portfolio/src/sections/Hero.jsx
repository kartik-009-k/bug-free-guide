import { useState, useEffect } from 'react';
import ParticleField from '../components/ParticleField.jsx';

const Hero = ({ mouseX, mouseY }) => {
  const [ld, setLd] = useState(false);
  useEffect(() => { setTimeout(() => setLd(true), 100); }, []);

  return (
    <section style={{ minHeight:'100vh', display:'flex', alignItems:'center', position:'relative', overflow:'hidden', padding:'100px 40px 60px' }}>
      <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(255,208,0,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,208,0,.025) 1px,transparent 1px)', backgroundSize:'40px 40px', animation:'gridMove 20s linear infinite', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', inset:0, background:'radial-gradient(ellipse 65% 70% at 50% 45%, rgba(255,208,0,.06) 0%, rgba(255,170,0,.03) 40%, transparent 70%)', pointerEvents:'none' }}/>
      <ParticleField mouseX={mouseX} mouseY={mouseY}/>

      <div style={{ position:'relative', zIndex:1, maxWidth:700, margin:'0 auto' }}>
        <div style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'6px 16px', borderRadius:100, border:'1px solid var(--border2)', background:'rgba(255,208,0,.05)', marginBottom:32, opacity:ld?1:0, transform:ld?'none':'translateY(20px)', transition:'all .8s ease .1s' }}>
          <div style={{ width:6, height:6, borderRadius:'50%', background:'var(--accent3)', animation:'pulse-glow 2s infinite' }}/>
          <span className="mono" style={{ fontSize:11, color:'var(--text2)', letterSpacing:'.12em' }}>AVAILABLE FOR COLLABORATION</span>
        </div>

        <h1 className="syne" style={{ fontSize:'clamp(44px,7.5vw,88px)', fontWeight:800, lineHeight:1.0, letterSpacing:'-.03em', marginBottom:28, opacity:ld?1:0, transform:ld?'none':'translateY(30px)', transition:'all .9s ease .2s' }}>
          BUILDING<br/>
          <span style={{ background:'linear-gradient(135deg,#ffd000 0%,#ffaa00 50%,#ffe566 100%)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>IDEAS INTO</span><br/>
          REALITY
        </h1>

        <div style={{ opacity:ld?1:0, transform:ld?'none':'translateY(20px)', transition:'all .9s ease .3s' }}>
          <p style={{ fontSize:18, color:'var(--text2)', lineHeight:1.7, marginBottom:8, fontWeight:300 }}>Curious Builder. Aspiring Software Engineer. Problem Solver.</p>
          <p style={{ fontSize:14, color:'var(--text3)', lineHeight:1.85, maxWidth:460, marginBottom:40 }}>I don't just learn technology. I enjoy understanding systems, solving problems, and turning ideas into reality.</p>
        </div>

        <div style={{ display:'flex', gap:16, flexWrap:'wrap', opacity:ld?1:0, transform:ld?'none':'translateY(20px)', transition:'all .9s ease .4s' }}>
          <button data-hover onClick={() => document.querySelector('#skills')?.scrollIntoView({ behavior:'smooth' })}
            style={{ padding:'14px 32px', borderRadius:100, background:'var(--accent)', border:'none', color:'#0a0900', fontSize:14, fontWeight:700, cursor:'pointer', letterSpacing:'.05em', fontFamily:'var(--font-body)', boxShadow:'0 0 36px rgba(255,208,0,.35)', transition:'transform .2s,box-shadow .2s' }}
            onMouseEnter={e => { e.target.style.transform='translateY(-2px)'; e.target.style.boxShadow='0 8px 40px rgba(255,208,0,.55)'; }}
            onMouseLeave={e => { e.target.style.transform='translateY(0)'; e.target.style.boxShadow='0 0 36px rgba(255,208,0,.35)'; }}>
            Explore Portfolio
          </button>
          <button data-hover onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior:'smooth' })}
            style={{ padding:'14px 32px', borderRadius:100, background:'transparent', border:'1px solid var(--border2)', color:'var(--text)', fontSize:14, fontWeight:500, cursor:'pointer', letterSpacing:'.05em', fontFamily:'var(--font-body)', transition:'all .2s' }}
            onMouseEnter={e => { e.target.style.borderColor='var(--accent)'; e.target.style.color='var(--accent)'; }}
            onMouseLeave={e => { e.target.style.borderColor='var(--border2)'; e.target.style.color='var(--text)'; }}>
            Contact Me
          </button>
        </div>

        <div style={{ display:'flex', gap:10, marginTop:48, flexWrap:'wrap', opacity:ld?1:0, transition:'opacity 1s ease .6s' }}>
          {['Maharashtra, India','Class XII','Future Engineer','Builder'].map(t => (
            <span key={t} className="mono" style={{ fontSize:10, color:'var(--text3)', padding:'4px 12px', borderRadius:100, border:'1px solid var(--border)', letterSpacing:'.1em' }}>{t}</span>
          ))}
        </div>
      </div>

      <div style={{ position:'absolute', bottom:32, left:'50%', transform:'translateX(-50%)', display:'flex', flexDirection:'column', alignItems:'center', gap:8, opacity:.35 }}>
        <span className="mono" style={{ fontSize:9, letterSpacing:'.2em', color:'var(--text3)' }}>SCROLL</span>
        <div style={{ width:1, height:40, background:'linear-gradient(to bottom,var(--accent),transparent)', animation:'float 2s ease-in-out infinite' }}/>
      </div>
    </section>
  );
};

export default Hero;
