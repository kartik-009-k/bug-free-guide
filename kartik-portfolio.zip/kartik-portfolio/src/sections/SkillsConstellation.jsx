import { useState } from 'react';

const NODES = [
  { id:'cpp',  label:'C++',             x:50, y:18, connections:['dsa','algo'],          color:'#ffd000', level:'Foundation' },
  { id:'dsa',  label:'DSA',             x:25, y:36, connections:['cpp','algo','js'],      color:'#ffaa00', level:'Core'       },
  { id:'algo', label:'Algorithms',      x:72, y:36, connections:['cpp','dsa'],            color:'#ffaa00', level:'Core'       },
  { id:'react',label:'React',           x:14, y:62, connections:['js','ts','html','css'], color:'#ffe566', level:'Frontend'   },
  { id:'js',   label:'JavaScript',      x:38, y:58, connections:['react','ts','html'],    color:'#ffd000', level:'Language'   },
  { id:'ts',   label:'TypeScript',      x:62, y:58, connections:['js','react'],           color:'#ffcc00', level:'Language'   },
  { id:'html', label:'HTML',            x:20, y:80, connections:['css','react','js'],     color:'#ffb300', level:'Web'        },
  { id:'css',  label:'CSS',             x:42, y:80, connections:['html','react'],         color:'#ffe566', level:'Web'        },
  { id:'git',  label:'Git',             x:80, y:70, connections:['cpp','js'],             color:'#ffaa00', level:'Tool'       },
  { id:'ps',   label:'Problem Solving', x:60, y:88, connections:['dsa','algo'],           color:'#fff0a0', level:'Mindset'    },
  { id:'pt',   label:'Product Thinking',x:86, y:44, connections:['ps'],                  color:'#ffd000', level:'Mindset'    },
];

const SkillsConstellation = () => {
  const [active, setActive] = useState(null);
  const gn = id => NODES.find(n => n.id === id);
  const an = active ? gn(active) : null;
  const ci = an ? new Set([active, ...an.connections]) : new Set();

  return (
    <section id="skills" style={{ padding:'120px 40px', maxWidth:1200, margin:'0 auto' }}>
      <div className="reveal-on-scroll" style={{ marginBottom:60 }}>
        <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:16 }}>
          <div style={{ width:32, height:1, background:'var(--accent)' }}/>
          <span className="mono" style={{ fontSize:11, color:'var(--accent)', letterSpacing:'.2em' }}>KNOWLEDGE MAP</span>
        </div>
        <h2 className="syne" style={{ fontSize:'clamp(36px,5vw,56px)', fontWeight:800, letterSpacing:'-.02em' }}>Skills<br/><span style={{ color:'var(--text3)' }}>Constellation</span></h2>
        <p style={{ color:'var(--text2)', marginTop:16, fontSize:14 }}>Hover nodes to reveal connections</p>
      </div>

      <div className="reveal-on-scroll" style={{ position:'relative', height:520, background:'var(--surface)', borderRadius:24, border:'1px solid var(--border)', overflow:'hidden' }}>
        <div style={{ position:'absolute', inset:0, backgroundImage:'radial-gradient(circle,rgba(255,208,0,.05) 1px,transparent 1px)', backgroundSize:'32px 32px' }}/>
        <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none' }}>
          {NODES.map(n => n.connections.map(cid => {
            const t = gn(cid);
            if (!t || n.id > cid) return null;
            const ia = active && (ci.has(n.id) && ci.has(cid));
            return <line key={`${n.id}-${cid}`} x1={`${n.x}%`} y1={`${n.y}%`} x2={`${t.x}%`} y2={`${t.y}%`} stroke={ia?n.color:'rgba(255,208,0,.06)'} strokeWidth={ia?2:1} style={{ transition:'all .3s ease' }}/>;
          }))}
        </svg>
        {NODES.map(n => {
          const ia = active === n.id, ic = ci.has(n.id), dim = active && !ic;
          return (
            <div key={n.id} data-hover onMouseEnter={() => setActive(n.id)} onMouseLeave={() => setActive(null)}
              style={{ position:'absolute', left:`${n.x}%`, top:`${n.y}%`, transform:'translate(-50%,-50%)', cursor:'pointer', zIndex:10, transition:'all .3s ease', opacity:dim?.2:1 }}>
              <div style={{ padding:ia?'12px 20px':'8px 16px', borderRadius:100, background:ia?`${n.color}18`:'rgba(255,255,255,.02)', border:`1px solid ${ia||ic?n.color:'rgba(255,208,0,.1)'}`, backdropFilter:'blur(10px)', boxShadow:ia?`0 0 24px ${n.color}40`:'none', transition:'all .3s ease', whiteSpace:'nowrap' }}>
                <span className="syne" style={{ fontSize:ia?13:12, fontWeight:700, color:ia?n.color:'var(--text2)', transition:'all .3s' }}>{n.label}</span>
                {ia && <div className="mono" style={{ fontSize:9, color:n.color, opacity:.7, textAlign:'center', marginTop:2, letterSpacing:'.1em' }}>{n.level}</div>}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default SkillsConstellation;
