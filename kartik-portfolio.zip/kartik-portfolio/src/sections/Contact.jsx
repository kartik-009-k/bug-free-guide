import { useState } from 'react';

// ── Replace with your deployed Google Apps Script Web App URL ─────────────────
// Steps:
//   1. Go to script.google.com → New project
//   2. Paste the doPost function below into the editor
//   3. Deploy → New deployment → Web app → Execute as: Me, Who has access: Anyone
//   4. Copy the Web App URL and paste it here
//
// function doPost(e) {
//   const data = JSON.parse(e.postData.contents);
//   SpreadsheetApp.openById("YOUR_GOOGLE_SHEET_ID")
//     .getActiveSheet()
//     .appendRow([data.timestamp, data.name, data.email, data.message]);
//   return ContentService.createTextOutput("OK");
// }
const SCRIPT_URL = 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec';

const LINKS = [
  { label:'Email',    value:'kartik@example.com',    icon:'✉', href:'mailto:kartik@example.com' },
  { label:'GitHub',   value:'github.com/kartik',      icon:'◈', href:'https://github.com/kartik' },
  { label:'LinkedIn', value:'linkedin.com/in/kartik', icon:'◆', href:'https://linkedin.com/in/kartik' },
];

const Contact = () => {
  const [fd,     setFd]     = useState({ name:'', email:'', message:'' });
  const [status, setStatus] = useState('idle'); // idle | sending | sent | error

  const handleSubmit = async () => {
    if (!fd.name || !fd.email || !fd.message) return;
    setStatus('sending');
    try {
      await fetch(SCRIPT_URL, {
        method: 'POST',
        mode: 'no-cors', // required for Google Apps Script cross-origin POST
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...fd, timestamp: new Date().toISOString() }),
      });
      // no-cors means we can't read the response body, so we assume success
      setStatus('sent');
      setFd({ name:'', email:'', message:'' });
      setTimeout(() => setStatus('idle'), 4000);
    } catch {
      setStatus('error');
      setTimeout(() => setStatus('idle'), 3000);
    }
  };

  const inp = {
    width:'100%', padding:'14px 18px', borderRadius:10,
    border:'1px solid var(--border2)', background:'rgba(255,208,0,.03)',
    color:'var(--text)', fontSize:14, fontFamily:'var(--font-body)',
    outline:'none', transition:'border-color .2s, background .2s',
  };

  return (
    <section id="contact" style={{ padding:'120px 40px', position:'relative', overflow:'hidden' }}>
      <div style={{ position:'absolute', inset:0, background:'linear-gradient(270deg,rgba(255,208,0,.06),rgba(255,170,0,.04),rgba(255,230,80,.03))', backgroundSize:'400% 400%', animation:'aurora 10s ease infinite', pointerEvents:'none' }}/>
      <div style={{ maxWidth:860, margin:'0 auto', position:'relative', zIndex:1 }}>

        {/* Header */}
        <div className="reveal-on-scroll" style={{ textAlign:'center', marginBottom:72 }}>
          <div style={{ display:'flex', alignItems:'center', gap:16, justifyContent:'center', marginBottom:20 }}>
            <div style={{ width:32, height:1, background:'var(--accent)' }}/>
            <span className="mono" style={{ fontSize:11, color:'var(--accent)', letterSpacing:'.2em' }}>GET IN TOUCH</span>
            <div style={{ width:32, height:1, background:'var(--accent)' }}/>
          </div>
          <h2 className="syne" style={{ fontSize:'clamp(36px,5vw,56px)', fontWeight:800, letterSpacing:'-.02em', marginBottom:16 }}>
            Let's Build Something<br/>
            <span style={{ background:'linear-gradient(135deg,#ffd000,#ffaa00)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>Meaningful.</span>
          </h2>
          <p style={{ color:'var(--text2)', fontSize:15 }}>Open to conversations about technology, ideas, and collaboration.</p>
        </div>

        {/* Social links */}
        <div className="reveal-on-scroll" style={{ display:'flex', gap:16, justifyContent:'center', flexWrap:'wrap', marginBottom:64 }}>
          {LINKS.map((l, i) => (
            <a key={i} href={l.href} data-hover
              style={{ display:'flex', alignItems:'center', gap:12, padding:'14px 24px', borderRadius:12, border:'1px solid var(--border)', background:'var(--surface)', textDecoration:'none', color:'var(--text)', transition:'all .2s', flex:'1 1 200px', maxWidth:260 }}
              onMouseEnter={e => { e.currentTarget.style.borderColor='rgba(255,208,0,.35)'; e.currentTarget.style.background='var(--surface2)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.background='var(--surface)'; }}>
              <span style={{ fontSize:20, color:'var(--accent)', width:26, flexShrink:0 }}>{l.icon}</span>
              <div>
                <div className="mono" style={{ fontSize:10, color:'var(--text3)', letterSpacing:'.1em', marginBottom:2 }}>{l.label}</div>
                <div style={{ fontSize:13, color:'var(--text2)' }}>{l.value}</div>
              </div>
            </a>
          ))}
        </div>

        {/* Message form */}
        <div className="reveal-on-scroll" style={{ transitionDelay:'.15s', background:'var(--surface)', border:'1px solid var(--border)', borderRadius:20, padding:'48px', maxWidth:640, margin:'0 auto' }}>
          <h3 className="syne" style={{ fontSize:18, fontWeight:700, marginBottom:32, textAlign:'center', color:'var(--text)' }}>Send a Message</h3>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:16 }}>
            <input placeholder="Your name" value={fd.name} onChange={e => setFd(f => ({ ...f, name:e.target.value }))}
              style={inp}
              onFocus={e => { e.target.style.borderColor='var(--accent)'; e.target.style.background='rgba(255,208,0,.05)'; }}
              onBlur={e  => { e.target.style.borderColor='var(--border2)'; e.target.style.background='rgba(255,208,0,.03)'; }}/>
            <input placeholder="Your email" value={fd.email} onChange={e => setFd(f => ({ ...f, email:e.target.value }))}
              style={inp}
              onFocus={e => { e.target.style.borderColor='var(--accent)'; e.target.style.background='rgba(255,208,0,.05)'; }}
              onBlur={e  => { e.target.style.borderColor='var(--border2)'; e.target.style.background='rgba(255,208,0,.03)'; }}/>
          </div>

          <textarea placeholder="Your message — ideas, collaborations, just saying hi..." rows={5}
            value={fd.message} onChange={e => setFd(f => ({ ...f, message:e.target.value }))}
            style={{ ...inp, resize:'none', marginBottom:24 }}
            onFocus={e => { e.target.style.borderColor='var(--accent)'; e.target.style.background='rgba(255,208,0,.05)'; }}
            onBlur={e  => { e.target.style.borderColor='var(--border2)'; e.target.style.background='rgba(255,208,0,.03)'; }}/>

          <button data-hover onClick={handleSubmit} disabled={status === 'sending'}
            style={{
              width:'100%', padding:'16px', borderRadius:100, border:'none',
              background: status==='sent' ? 'rgba(255,208,0,.15)' : status==='error' ? 'rgba(255,80,80,.15)' : 'var(--accent)',
              color: status==='sent'||status==='error' ? 'var(--text)' : '#0a0900',
              fontSize:15, fontWeight:700, cursor:status==='sending'?'wait':'pointer',
              fontFamily:'var(--font-body)', letterSpacing:'.05em', transition:'all .3s',
              boxShadow: status==='idle' ? '0 0 32px rgba(255,208,0,.25)' : 'none',
              outline: status==='sent' ? '1px solid rgba(255,208,0,.4)' : 'none',
            }}>
            {status==='idle'    && 'Send Message →'}
            {status==='sending' && 'Sending...'}
            {status==='sent'    && '✓ Message Sent — Thanks!'}
            {status==='error'   && 'Something went wrong. Try again.'}
          </button>

          <p className="mono" style={{ fontSize:10, color:'var(--text3)', textAlign:'center', marginTop:16, letterSpacing:'.08em' }}>
            Powered by Google Sheets · Responses logged automatically
          </p>
        </div>

      </div>
    </section>
  );
};

export default Contact;
