const PROJECTS = [
  { label:'Project Alpha', type:'Web App',       progress:12 },
  { label:'Project Beta',  type:'Tool / Utility', progress:5  },
  { label:'Project Gamma', type:'Experiment',     progress:3  },
];

const BuildingInPublic = () => (
  <section style={{ padding:'120px 40px', background:'var(--surface)', position:'relative', overflow:'hidden' }}>
    <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(255,208,0,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,208,0,.03) 1px,transparent 1px)', backgroundSize:'32px 32px', pointerEvents:'none' }}/>
    <div style={{ maxWidth:1200, margin:'0 auto', position:'relative', zIndex:1 }}>

      <div className="reveal-on-scroll" style={{ textAlign:'center', marginBottom:80 }}>
        <div style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'6px 20px', borderRadius:100, border:'1px solid rgba(255,208,0,.25)', background:'rgba(255,208,0,.04)', marginBottom:24 }}>
          <span>🚧</span>
          <span className="mono" style={{ fontSize:11, color:'var(--accent)', letterSpacing:'.15em' }}>TO BE UPDATED</span>
        </div>
        <h2 className="syne" style={{ fontSize:'clamp(36px,5vw,56px)', fontWeight:800, marginBottom:20, letterSpacing:'-.02em' }}>Building in Public</h2>
        <p style={{ color:'var(--text2)', maxWidth:540, margin:'0 auto', lineHeight:1.8, fontSize:15 }}>This section intentionally remains unfinished. Currently focused on learning, experimenting, and building projects worth showcasing.</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))', gap:24, marginBottom:60 }}>
        {PROJECTS.map((bp, i) => (
          <div key={i} className="reveal-on-scroll" style={{ transitionDelay:`${i*.1}s`, padding:32, borderRadius:16, border:'1px solid var(--border)', background:'rgba(255,208,0,.015)', position:'relative', overflow:'hidden' }}>
            <div style={{ position:'absolute', top:12, left:12, width:20, height:20, borderTop:'1px solid var(--accent)', borderLeft:'1px solid var(--accent)', opacity:.4 }}/>
            <div style={{ position:'absolute', bottom:12, right:12, width:20, height:20, borderBottom:'1px solid var(--accent)', borderRight:'1px solid var(--accent)', opacity:.4 }}/>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:24 }}>
              <div>
                <div className="mono" style={{ fontSize:10, color:'var(--text3)', letterSpacing:'.15em', marginBottom:8 }}>{bp.type}</div>
                <div className="syne" style={{ fontSize:18, fontWeight:700, color:'var(--text2)' }}>{bp.label}</div>
              </div>
              <div style={{ padding:'4px 10px', borderRadius:6, background:'rgba(255,208,0,.08)', border:'1px solid rgba(255,208,0,.18)' }}>
                <span className="mono" style={{ fontSize:9, color:'var(--accent)', letterSpacing:'.1em' }}>FORMING</span>
              </div>
            </div>
            <div style={{ marginBottom:20 }}>
              {[0,1,2,3].map(j => (
                <div key={j} style={{ height:6, borderRadius:3, background:'rgba(255,208,0,.07)', marginBottom:8, position:'relative', overflow:'hidden' }}>
                  <div style={{ position:'absolute', inset:0, width:`${bp.progress+j*5}%`, background:'rgba(255,208,0,.2)', borderRadius:3, animation:'constructLine 2s ease forwards', animationDelay:`${j*.2+i*.3}s` }}/>
                </div>
              ))}
            </div>
            <div style={{ display:'flex', justifyContent:'space-between' }}>
              <span className="mono" style={{ fontSize:10, color:'var(--text3)' }}>In progress...</span>
              <span className="mono" style={{ fontSize:10, color:'var(--accent)', opacity:.6 }}>{bp.progress}%</span>
            </div>
          </div>
        ))}
      </div>

      <div className="reveal-on-scroll" style={{ textAlign:'center', padding:40, borderRadius:16, border:'1px solid var(--border)', background:'rgba(255,208,0,.015)' }}>
        <p style={{ fontSize:15, color:'var(--text2)', lineHeight:1.8, fontStyle:'italic' }}>
          Rather than filling this portfolio with tutorial clones, I only want to display work I'm genuinely proud of.<br/>
          <span style={{ color:'var(--accent)', fontStyle:'normal' }}>Future work will appear here.</span>
        </p>
      </div>

    </div>
  </section>
);

export default BuildingInPublic;
