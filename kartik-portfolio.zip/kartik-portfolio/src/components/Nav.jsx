const Nav = ({ scrolled }) => (
  <nav style={{ position:'fixed', top:0, left:0, right:0, zIndex:1000, padding:'16px 40px', display:'flex', alignItems:'center', justifyContent:'space-between', backdropFilter:scrolled?'blur(20px)':'none', borderBottom:scrolled?'1px solid var(--border)':'none', background:scrolled?'rgba(10,9,0,.92)':'transparent', transition:'all .4s ease' }}>
    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
      <div style={{ width:8, height:8, borderRadius:'50%', background:'var(--accent)', animation:'pulse-glow 2s infinite' }}/>
      <span className="syne" style={{ fontSize:16, fontWeight:700, letterSpacing:'.05em' }}>KG</span>
      <span className="mono" style={{ fontSize:10, color:'var(--text2)', letterSpacing:'.1em' }}>v1.0</span>
    </div>
    <div style={{ display:'flex', gap:32 }}>
      {['About','Skills','Contact'].map(l => (
        <a key={l} href={`#${l.toLowerCase()}`} data-hover
          style={{ color:'var(--text2)', textDecoration:'none', fontSize:13, fontWeight:500, letterSpacing:'.05em', transition:'color .2s' }}
          onMouseEnter={e => e.target.style.color='var(--accent)'}
          onMouseLeave={e => e.target.style.color='var(--text2)'}>{l}</a>
      ))}
    </div>
  </nav>
);

export default Nav;
