import { useState, useEffect, useRef } from 'react';

const Cursor = () => {
  const dot = useRef(null);
  const ring = useRef(null);
  const pos = useRef({ x: 0, y: 0 });
  const rp = useRef({ x: 0, y: 0 });
  const [hov, setHov] = useState(false);

  useEffect(() => {
    const mv = e => {
      pos.current = { x: e.clientX, y: e.clientY };
      if (dot.current) dot.current.style.transform = `translate(${e.clientX - 4}px,${e.clientY - 4}px)`;
    };
    window.addEventListener('mousemove', mv);
    let raf;
    const loop = () => {
      rp.current.x += (pos.current.x - rp.current.x) * 0.12;
      rp.current.y += (pos.current.y - rp.current.y) * 0.12;
      if (ring.current) ring.current.style.transform = `translate(${rp.current.x - 20}px,${rp.current.y - 20}px)`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const on = () => setHov(true);
    const off = () => setHov(false);
    document.querySelectorAll('a,button,[data-hover]').forEach(el => {
      el.addEventListener('mouseenter', on);
      el.addEventListener('mouseleave', off);
    });
    return () => { window.removeEventListener('mousemove', mv); cancelAnimationFrame(raf); };
  }, []);

  return (
    <>
      <div ref={dot} style={{ position:'fixed',top:0,left:0,width:8,height:8,borderRadius:'50%',background:'var(--accent)',zIndex:9999,pointerEvents:'none',willChange:'transform' }} />
      <div ref={ring} style={{ position:'fixed',top:0,left:0,width:hov?56:40,height:hov?56:40,marginLeft:hov?-8:0,marginTop:hov?-8:0,borderRadius:'50%',border:`1.5px solid ${hov?'var(--accent)':'rgba(255,208,0,0.38)'}`,zIndex:9998,pointerEvents:'none',willChange:'transform',transition:'width .2s,height .2s,border-color .2s,margin .2s' }} />
    </>
  );
};

export default Cursor;
