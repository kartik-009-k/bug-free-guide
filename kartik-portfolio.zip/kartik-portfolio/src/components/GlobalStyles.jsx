const GlobalStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&family=JetBrains+Mono:wght@300;400;500&display=swap');
    *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
    :root {
      --bg:#0a0900;
      --surface:#0f0e00;
      --surface2:#161400;
      --border:rgba(255,210,0,0.07);
      --border2:rgba(255,210,0,0.14);
      --text:#f5f0d8;
      --text2:#a09870;
      --text3:#5a5030;
      --accent:#ffd000;
      --accent2:#ffaa00;
      --accent3:#ffe566;
      --accentDim:rgba(255,208,0,0.12);
      --font-display:'Syne',sans-serif;
      --font-body:'DM Sans',sans-serif;
      --font-mono:'JetBrains Mono',monospace;
    }
    html { scroll-behavior:smooth; }
    body { background:var(--bg); color:var(--text); font-family:var(--font-body); overflow-x:hidden; cursor:none; }
    ::-webkit-scrollbar { width:3px; }
    ::-webkit-scrollbar-track { background:var(--bg); }
    ::-webkit-scrollbar-thumb { background:var(--accent); border-radius:10px; }
    .syne { font-family:var(--font-display); }
    .mono { font-family:var(--font-mono); }
    @keyframes pulse-glow   { 0%,100%{opacity:0.35} 50%{opacity:1} }
    @keyframes spin-slow    { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
    @keyframes aurora       { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
    @keyframes gridMove     { from{background-position:0 0} to{background-position:40px 40px} }
    @keyframes float        { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
    @keyframes constructLine{ from{width:0} to{width:100%} }
    @keyframes scanline     { 0%{transform:translateY(-200%)} 100%{transform:translateY(600%)} }
    @keyframes trailFade    { 0%{opacity:0.5;transform:scale(1)} 100%{opacity:0;transform:scale(0.1)} }
    @keyframes speechPop    { 0%{opacity:0;transform:translateX(-50%) scale(0.6) translateY(10px)} 70%{transform:translateX(-50%) scale(1.04) translateY(-2px)} 100%{opacity:1;transform:translateX(-50%) scale(1) translateY(0)} }
    @keyframes shadowPulse  { 0%,100%{opacity:0.35;transform:translateX(-50%) scaleX(1)} 50%{opacity:0.55;transform:translateX(-50%) scaleX(1.08)} }
    @keyframes shimmerBar   { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
    @keyframes spinOnce     { 0%{transform:scaleX(var(--fx)) rotate(0deg)} 100%{transform:scaleX(var(--fx)) rotate(360deg)} }
    @keyframes heartFloat   { 0%{opacity:1;transform:translateY(0) scale(1)} 100%{opacity:0;transform:translateY(-60px) scale(1.6)} }
    @keyframes scaredShake  { 0%,100%{transform:scaleX(var(--fx)) translateX(0)} 20%{transform:scaleX(var(--fx)) translateX(-6px)} 40%{transform:scaleX(var(--fx)) translateX(6px)} 60%{transform:scaleX(var(--fx)) translateX(-4px)} 80%{transform:scaleX(var(--fx)) translateX(4px)} }
    @keyframes popBounce    { 0%{transform:scaleX(var(--fx)) scale(1)} 30%{transform:scaleX(var(--fx)) scale(1.18)} 60%{transform:scaleX(var(--fx)) scale(0.92)} 100%{transform:scaleX(var(--fx)) scale(1)} }
    @keyframes zoomOut      { 0%{transform:translateX(-50%) scale(0)} 60%{transform:translateX(-50%) scale(1.2)} 100%{transform:translateX(-50%) scale(1)} }
    @keyframes floatEmoji   { 0%{opacity:1;transform:translateX(-50%) translateY(0) scale(1)} 100%{opacity:0;transform:translateX(-50%) translateY(-70px) scale(1.4)} }
    .reveal-on-scroll { opacity:0; transform:translateY(40px); transition:opacity 0.8s ease, transform 0.8s ease; }
    .reveal-on-scroll.visible { opacity:1; transform:translateY(0); }
    input::placeholder, textarea::placeholder { color: var(--text3); }
    input, textarea { color-scheme: dark; }
  `}</style>
);

export default GlobalStyles;
