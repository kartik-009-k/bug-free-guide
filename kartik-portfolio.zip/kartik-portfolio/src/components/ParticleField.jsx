import { useEffect, useRef } from 'react';

const ParticleField = ({ mouseX, mouseY }) => {
  const cvs = useRef(null);
  const pts = useRef([]);
  const raf = useRef(null);

  useEffect(() => {
    const c = cvs.current;
    const ctx = c.getContext('2d');
    const rz = () => { c.width = window.innerWidth; c.height = window.innerHeight; };
    rz();
    window.addEventListener('resize', rz);
    for (let i = 0; i < 100; i++) pts.current.push({
      x: Math.random() * c.width, y: Math.random() * c.height,
      vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3,
      r: Math.random() * 1.4 + .3, op: Math.random() * .35 + .08,
      hue: [45, 38, 52][Math.floor(Math.random() * 3)],
    });
    const draw = () => {
      ctx.clearRect(0, 0, c.width, c.height);
      const mx = mouseX.current, my = mouseY.current;
      pts.current.forEach(p => {
        const dx = mx - p.x, dy = my - p.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
        if (d < 160) { p.vx += dx / d * .018; p.vy += dy / d * .018; }
        p.vx *= .99; p.vy *= .99; p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = c.width; if (p.x > c.width) p.x = 0;
        if (p.y < 0) p.y = c.height; if (p.y > c.height) p.y = 0;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue},90%,65%,${p.op})`; ctx.fill();
      });
      pts.current.forEach((p, i) => pts.current.slice(i + 1).forEach(q => {
        const d = Math.hypot(p.x - q.x, p.y - q.y);
        if (d < 90) {
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(255,208,0,${.06 * (1 - d / 90)})`; ctx.lineWidth = .5; ctx.stroke();
        }
      }));
      raf.current = requestAnimationFrame(draw);
    };
    draw();
    return () => { window.removeEventListener('resize', rz); cancelAnimationFrame(raf.current); };
  }, []);

  return <canvas ref={cvs} style={{ position:'absolute', inset:0, pointerEvents:'none', zIndex:0 }} />;
};

export default ParticleField;
