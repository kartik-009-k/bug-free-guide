import { useState, useEffect, useRef } from 'react';
import AnimatedRobot from './AnimatedRobot.jsx';

const LINES = [
  "Hello! 👋","Always learning...","Building cool stuff!","I see you 👀",
  "let me = explore()","More below! ↓","Hello World! 🌍","// TODO: be awesome",
  "React + ❤️","Curiosity > Fear","git commit -m 'growth'","Stay curious!",
  "DSA is fun!","Systems thinking!","Compiling ideas...","Keep going! 🚀",
  "1% better daily","Ship it! 🛸",
];

const RoamingRobot = ({ mouseX, mouseY }) => {
  const W = 110, H = 180, EDGE = 14;
  const posR  = useRef({ x: window.innerWidth - W - 40, y: 160 });
  const velR  = useRef({ x: -0.4, y: 0.3 });
  const tgtR  = useRef({ x: window.innerWidth - W - 40, y: 160 });
  const walkP = useRef(0), rafR = useRef(null), trailId = useRef(0), trailBuf = useRef(0);

  const [pos,       setPos]       = useState(posR.current);
  const [flip,      setFlip]      = useState(false);
  const [walkPhase, setWalkPhase] = useState(0);
  const [speed,     setSpeed]     = useState(0);
  const [eyeX,      setEyeX]      = useState(0);
  const [eyeY,      setEyeY]      = useState(0);
  const [headTilt,  setHeadTilt]  = useState(0);
  const [blink,     setBlink]     = useState(false);
  const [mouth,     setMouth]     = useState('idle');
  const [waving,    setWaving]    = useState(false);
  const [excited,   setExcited]   = useState(false);
  const [jumping,   setJumping]   = useState(false);
  const [scared,    setScared]    = useState(false);
  const [spinning,  setSpinning]  = useState(false);
  const [glow,      setGlow]      = useState(0.65);
  const [speech,    setSpeech]    = useState(null);
  const [floaties,  setFloaties]  = useState([]);
  const [trail,     setTrail]     = useState([]);
  const spKey       = useRef(0);
  const floatKey    = useRef(0);
  const clickCount  = useRef(0);
  const clickTimer  = useRef(null);
  const lastTouch   = useRef(0);

  const pickTarget = () => {
    const vw = window.innerWidth, vh = window.innerHeight, BAND = 140;
    const opts = [
      { x: EDGE + Math.random() * BAND,                        y: EDGE + Math.random() * (vh - H - EDGE * 2) },
      { x: vw - W - EDGE - Math.random() * BAND,               y: EDGE + Math.random() * (vh - H - EDGE * 2) },
      { x: EDGE + Math.random() * (vw - W - EDGE * 2),         y: EDGE + Math.random() * BAND },
      { x: EDGE + Math.random() * (vw - W - EDGE * 2),         y: vh - H - EDGE - Math.random() * BAND },
      { x: EDGE + Math.random() * 80,                          y: EDGE + Math.random() * 80 },
      { x: vw - W - EDGE - Math.random() * 80,                  y: EDGE + Math.random() * 80 },
      { x: EDGE + Math.random() * 80,                          y: vh - H - EDGE - Math.random() * 80 },
      { x: vw - W - EDGE - Math.random() * 80,                  y: vh - H - EDGE - Math.random() * 80 },
    ];
    return opts[Math.floor(Math.random() * opts.length)];
  };

  const showSpeech = txt => {
    setSpeech({ txt, id: spKey.current++ });
    setTimeout(() => setSpeech(null), 2800);
  };

  const spawnFloatie = emoji => {
    const id = floatKey.current++;
    setFloaties(prev => [...prev.slice(-6), { emoji, id }]);
    setTimeout(() => setFloaties(prev => prev.filter(f => f.id !== id)), 1200);
  };

  // Blink loop
  useEffect(() => {
    let t;
    const blinker = () => { setBlink(true); setTimeout(() => setBlink(false), 110); t = setTimeout(blinker, 1400 + Math.random() * 4000); };
    t = setTimeout(blinker, 1800);
    return () => clearTimeout(t);
  }, []);

  // Personality events
  useEffect(() => {
    let t;
    const ev = () => {
      const r = Math.random();
      if (r < 0.2)       { setWaving(true); setMouth('happy'); showSpeech(LINES[Math.floor(Math.random()*LINES.length)]); setTimeout(() => { setWaving(false); setMouth('idle'); }, 2200); }
      else if (r < 0.38) { setJumping(true); setExcited(true); setMouth('excited'); setTimeout(() => { setJumping(false); setExcited(false); setMouth('idle'); }, 800); }
      else if (r < 0.55) { setMouth('surprised'); showSpeech(LINES[Math.floor(Math.random()*LINES.length)]); setTimeout(() => setMouth('idle'), 1600); }
      else if (r < 0.70) { setExcited(true); setMouth('happy'); setTimeout(() => { setExcited(false); setMouth('idle'); }, 1200); }
      else               { velR.current = { x: (Math.random()-.5)*7, y: (Math.random()-.5)*6 }; tgtR.current = pickTarget(); }
      t = setTimeout(ev, 2500 + Math.random() * 4500);
    };
    t = setTimeout(ev, 3000);
    return () => clearTimeout(t);
  }, []);

  // Eye tracking
  useEffect(() => {
    const id = setInterval(() => {
      const p = posR.current, cx = p.x + W/2, cy = p.y + H * 0.26;
      const dx = mouseX.current - cx, dy = mouseY.current - cy, d = Math.sqrt(dx*dx+dy*dy)||1, MAX = 4.2;
      setEyeX(Math.max(-MAX, Math.min(MAX, dx/d * Math.min(d*.04, MAX))));
      setEyeY(Math.max(-MAX, Math.min(MAX, dy/d * Math.min(d*.036, MAX))));
      setHeadTilt(Math.max(-7, Math.min(7, dx * 0.01)));
    }, 16);
    return () => clearInterval(id);
  }, []);

  // Physics RAF loop
  useEffect(() => {
    const SPEED = 2.6, ACCEL = 0.075, FRIC = 0.958;
    tgtR.current = pickTarget();
    const loop = () => {
      const p = posR.current, v = velR.current, t = tgtR.current;
      const vw = window.innerWidth, vh = window.innerHeight;
      const dx = t.x - p.x, dy = t.y - p.y, d = Math.sqrt(dx*dx+dy*dy)||1;
      v.x += ((dx/d)*SPEED - v.x)*ACCEL; v.y += ((dy/d)*SPEED - v.y)*ACCEL;
      v.x *= FRIC; v.y *= FRIC; p.x += v.x; p.y += v.y;
      const maxX = vw-W-EDGE, maxY = vh-H-EDGE;
      if (p.x < EDGE)  { p.x = EDGE;  v.x =  Math.abs(v.x)*.55; }
      if (p.x > maxX)  { p.x = maxX;  v.x = -Math.abs(v.x)*.55; }
      if (p.y < EDGE)  { p.y = EDGE;  v.y =  Math.abs(v.y)*.55; }
      if (p.y > maxY)  { p.y = maxY;  v.y = -Math.abs(v.y)*.55; }
      if (d < 14) tgtR.current = pickTarget();
      const spd = Math.sqrt(v.x*v.x+v.y*v.y), norm = Math.min(spd/SPEED, 1);
      walkP.current += spd * 0.075;
      setPos({ x:p.x, y:p.y }); setFlip(v.x < -0.3); setSpeed(norm); setWalkPhase(walkP.current); setGlow(0.48 + norm*0.7);
      trailBuf.current++;
      if (trailBuf.current >= 4) {
        trailBuf.current = 0;
        const tid = trailId.current++;
        setTrail(prev => [...prev.slice(-12), { x:p.x+W/2, y:p.y+H*0.85, id:tid, s:spd }]);
      }
      rafR.current = requestAnimationFrame(loop);
    };
    rafR.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafR.current);
  }, []);

  // Scroll: pick new target
  useEffect(() => {
    const onS = () => { tgtR.current = pickTarget(); };
    window.addEventListener('scroll', onS, { passive:true });
    return () => window.removeEventListener('scroll', onS);
  }, []);

  // Cursor proximity flee
  useEffect(() => {
    const onMove = e => {
      const p = posR.current;
      const dx = e.clientX - (p.x+W/2), dy = e.clientY - (p.y+H/2);
      const dist = Math.sqrt(dx*dx+dy*dy);
      if (dist < 60 && !scared) {
        velR.current.x -= dx/dist * 1.2;
        velR.current.y -= dy/dist * 1.2;
      }
    };
    window.addEventListener('mousemove', onMove, { passive:true });
    return () => window.removeEventListener('mousemove', onMove);
  }, []);

  // Interaction handler (click + touch)
  const handleInteract = () => {
    const now = Date.now();
    if (now - lastTouch.current < 350) return;
    lastTouch.current = now;
    clickCount.current += 1;
    clearTimeout(clickTimer.current);
    clickTimer.current = setTimeout(() => { clickCount.current = 0; }, 600);
    const count = clickCount.current;

    if (count >= 5) {
      setSpinning(true); setMouth('surprised');
      spawnFloatie('💫'); spawnFloatie('⭐');
      showSpeech('Woah woah woah!!! 😵');
      velR.current = { x:(Math.random()-.5)*18, y:(Math.random()-.5)*15 };
      tgtR.current = pickTarget();
      setTimeout(() => { setSpinning(false); setMouth('idle'); clickCount.current = 0; }, 1200);
    } else if (count === 4) {
      setScared(true); setMouth('surprised');
      spawnFloatie('😱');
      showSpeech("Okay okay I'm going!! 😰");
      velR.current = { x:(Math.random()>.5?1:-1)*16, y:(Math.random()-.5)*10 };
      tgtR.current = pickTarget();
      setTimeout(() => { setScared(false); setMouth('idle'); }, 1500);
    } else if (count === 3) {
      setJumping(true); setExcited(true); setMouth('excited');
      spawnFloatie('❤️'); spawnFloatie('✨');
      showSpeech('You really like me! 🥹');
      setTimeout(() => { setJumping(false); setExcited(false); setMouth('idle'); }, 900);
    } else if (count === 2) {
      setWaving(true); setMouth('happy');
      spawnFloatie('👋');
      showSpeech(LINES[Math.floor(Math.random()*LINES.length)]);
      velR.current = { x:(Math.random()-.5)*8, y:(Math.random()-.5)*7 };
      tgtR.current = pickTarget();
      setTimeout(() => { setWaving(false); setMouth('idle'); }, 1800);
    } else {
      const reactions = [
        () => { setMouth('surprised'); spawnFloatie('❗'); showSpeech('Hey! 👀'); setTimeout(() => setMouth('idle'), 1000); },
        () => { setJumping(true); setMouth('excited'); spawnFloatie('🚀'); setTimeout(() => { setJumping(false); setMouth('idle'); }, 700); },
        () => { setWaving(true); setMouth('happy'); spawnFloatie('😄'); showSpeech(LINES[Math.floor(Math.random()*LINES.length)]); setTimeout(() => { setWaving(false); setMouth('idle'); }, 1600); },
        () => { setExcited(true); setMouth('happy'); spawnFloatie('⚡'); setTimeout(() => { setExcited(false); setMouth('idle'); }, 900); },
        () => { setMouth('surprised'); spawnFloatie('💡'); showSpeech('Just building! 🛠️'); setTimeout(() => setMouth('idle'), 1200); },
      ];
      reactions[Math.floor(Math.random()*reactions.length)]();
      velR.current = { x:(Math.random()-.5)*10, y:(Math.random()-.5)*9 };
      tgtR.current = pickTarget();
    }
  };

  return (
    <>
      {trail.map(t => (
        <div key={t.id} style={{ position:'fixed', left:t.x-5, top:t.y-4, width:10+t.s, height:6+t.s*0.4, borderRadius:'50%', background:`rgba(255,208,0,${0.12+t.s*.03})`, pointerEvents:'none', zIndex:8970, animation:'trailFade 0.7s ease forwards' }}/>
      ))}
      <div
        onClick={handleInteract}
        onTouchStart={e => { e.preventDefault(); handleInteract(); }}
        data-hover
        style={{
          position:'fixed', left:pos.x, top:pos.y, zIndex:9000,
          cursor:'pointer', userSelect:'none', willChange:'left,top',
          '--fx': flip ? -1 : 1,
          transform: `scaleX(${flip ? -1 : 1})`,
          animation: spinning ? 'spinOnce 0.55s ease forwards' : scared ? 'scaredShake 0.45s ease' : jumping ? 'popBounce 0.4s ease' : 'none',
          transformOrigin: 'center bottom',
          touchAction: 'none',
        }}
      >
        <div style={{ position:'absolute', inset:'-20px', background:`radial-gradient(ellipse at 50% 45%, rgba(255,208,0,${scared?0.35:glow*.16}) 0%, rgba(255,170,0,${glow*.07}) 50%, transparent 72%)`, pointerEvents:'none', transition:'background .2s' }}/>
        {floaties.map(f => (
          <div key={f.id} style={{ position:'absolute', bottom:'100%', left:'50%', fontSize:20, pointerEvents:'none', zIndex:2, animation:'floatEmoji 1.1s ease forwards', transform:'translateX(-50%)' }}>{f.emoji}</div>
        ))}
        {speech && (
          <div key={speech.id} style={{ position:'absolute', bottom:'calc(100% + 28px)', left:'50%', background:'rgba(10,9,0,0.97)', border:'1px solid rgba(255,208,0,.5)', borderRadius:12, padding:'6px 14px', fontSize:12, fontFamily:'var(--font-body)', color:'var(--text)', whiteSpace:'nowrap', backdropFilter:'blur(16px)', boxShadow:'0 4px 24px rgba(255,208,0,.25)', animation:'zoomOut .3s ease forwards', zIndex:3, pointerEvents:'none', transform:flip?'translateX(-50%) scaleX(-1)':'translateX(-50%)' }}>
            {speech.txt}
            <div style={{ position:'absolute', bottom:-6, left:'50%', transform:'translateX(-50%)', width:0, height:0, borderLeft:'5px solid transparent', borderRight:'5px solid transparent', borderTop:'6px solid rgba(255,208,0,.5)' }}/>
          </div>
        )}
        <AnimatedRobot eyeX={eyeX} eyeY={eyeY} headTilt={headTilt} blink={blink} mouth={scared?'surprised':mouth} walkPhase={walkPhase} speed={scared?1:speed} jumping={jumping} waving={waving} excited={excited||scared} glow={scared?1.3:glow} size={110}/>
        <div style={{ textAlign:'center', marginTop:0, fontFamily:'var(--font-mono)', fontSize:8, color:'var(--accent)', opacity:0.5, letterSpacing:'0.13em', pointerEvents:'none', transform:flip?'scaleX(-1)':'none' }}>Unit-01</div>
      </div>
    </>
  );
};

export default RoamingRobot;
