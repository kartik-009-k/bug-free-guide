const AnimatedRobot = ({ eyeX, eyeY, headTilt, blink, mouth, walkPhase, speed, jumping, waving, excited, glow, size = 110 }) => {
  const g = Math.max(0.3, Math.min(1.4, glow));
  const sw = Math.min(speed * 28, 26);
  const lsw = Math.min(speed * 22, 20);
  const bob = Math.min(speed * 3.5, 3.2);
  const leftArmRot = waving ? Math.sin(Date.now() * 0.01) * 35 - 20 : excited ? Math.sin(Date.now() * 0.016) * 40 : -Math.sin(walkPhase) * sw;
  const rightArmRot = excited ? Math.sin(walkPhase) * 40 : Math.sin(walkPhase) * sw;
  const leftLegRot = jumping ? -12 : Math.sin(walkPhase) * lsw;
  const rightLegRot = jumping ? 12 : -Math.sin(walkPhase) * lsw;
  const bodyBob = jumping ? -18 : -Math.abs(Math.sin(walkPhase)) * bob;
  const headRot = headTilt * 0.4;
  const mp = {
    idle:      'M 32 62 Q 40 67 48 62',
    surprised: 'M 34 60 Q 40 70 46 60',
    happy:     'M 29 58 Q 40 73 51 58',
    excited:   'M 27 57 Q 40 76 53 57',
  }[mouth] || 'M 32 62 Q 40 67 48 62';

  return (
    <svg viewBox="0 0 160 272" width={size} height={size * (272 / 160)}
      style={{ overflow:'visible', filter:`drop-shadow(0 0 ${14*g}px rgba(255,208,0,${.5*g})) drop-shadow(0 0 4px rgba(255,170,0,${.22*g}))` }}>
      <defs>
        <radialGradient id="rb" cx="50%" cy="40%" r="60%"><stop offset="0%" stopColor="#1e1a00"/><stop offset="100%" stopColor="#0d0b00"/></radialGradient>
        <radialGradient id="rh" cx="50%" cy="40%" r="60%"><stop offset="0%" stopColor="#1a1600"/><stop offset="100%" stopColor="#0c0a00"/></radialGradient>
        <radialGradient id="re" cx="50%" cy="50%" r="50%"><stop offset="0%" stopColor="#ffd000"/><stop offset="100%" stopColor="#cc9900" stopOpacity=".6"/></radialGradient>
        <filter id="gf"><feGaussianBlur stdDeviation="2.2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        <linearGradient id="ra" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stopColor="#ffd000"/><stop offset="100%" stopColor="#8a6a00"/></linearGradient>
        <linearGradient id="rc" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0%" stopColor="rgba(255,208,0,.22)"/><stop offset="100%" stopColor="rgba(255,208,0,.03)"/></linearGradient>
        <clipPath id="hc"><rect x="42" y="22" width="76" height="68" rx="14"/></clipPath>
      </defs>
      <g transform={`translate(0,${bodyBob})`}>
        {/* LEFT ARM */}
        <g transform={`translate(15,128) rotate(${leftArmRot}) translate(-15,-128)`} style={{ transformOrigin:'15px 122px' }}>
          <rect x="4" y="122" width="22" height="58" rx="11" fill="url(#rb)" stroke="rgba(255,208,0,.18)" strokeWidth="1"/>
          <rect x="8" y="142" width="14" height="26" rx="7" fill="rgba(255,208,0,.07)"/>
          <ellipse cx="15" cy="186" rx="11" ry="8" fill="url(#rb)" stroke="rgba(255,208,0,.18)" strokeWidth="1"/>
          <line x1="9" y1="184" x2="9" y2="188" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
          <line x1="15" y1="183" x2="15" y2="188" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
          <line x1="21" y1="184" x2="21" y2="188" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
        </g>
        {/* RIGHT ARM */}
        <g transform={`translate(145,128) rotate(${rightArmRot}) translate(-145,-128)`} style={{ transformOrigin:'145px 122px' }}>
          <rect x="134" y="122" width="22" height="58" rx="11" fill="url(#rb)" stroke="rgba(255,208,0,.18)" strokeWidth="1"/>
          <rect x="138" y="142" width="14" height="26" rx="7" fill="rgba(255,208,0,.07)"/>
          <ellipse cx="145" cy="186" rx="11" ry="8" fill="url(#rb)" stroke="rgba(255,208,0,.18)" strokeWidth="1"/>
          <line x1="139" y1="184" x2="139" y2="188" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
          <line x1="145" y1="183" x2="145" y2="188" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
          <line x1="151" y1="184" x2="151" y2="188" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
        </g>
        {/* SHOULDERS */}
        <ellipse cx="20" cy="120" rx="15" ry="11" fill="url(#rb)" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
        <ellipse cx="140" cy="120" rx="15" ry="11" fill="url(#rb)" stroke="rgba(255,208,0,.22)" strokeWidth="1"/>
        <circle cx="20" cy="120" r="4.5" fill="rgba(255,208,0,.18)" stroke="rgba(255,208,0,.5)" strokeWidth="1"/>
        <circle cx="140" cy="120" r="4.5" fill="rgba(255,208,0,.18)" stroke="rgba(255,208,0,.5)" strokeWidth="1"/>
        {/* BODY */}
        <rect x="30" y="100" width="100" height="92" rx="16" fill="url(#rb)" stroke="rgba(255,208,0,.25)" strokeWidth="1.5"/>
        <rect x="40" y="110" width="80" height="60" rx="10" fill="url(#rc)" stroke="rgba(255,208,0,.1)" strokeWidth="1"/>
        <circle cx="80" cy="134" r="16" fill="#0d0b00" stroke="rgba(255,208,0,.35)" strokeWidth="1.5"/>
        <circle cx="80" cy="134" r="11" fill="none" stroke="rgba(255,208,0,.45)" strokeWidth="1" style={{ animation:'spin-slow 8s linear infinite' }}/>
        <circle cx="80" cy="134" r="6" fill="rgba(255,208,0,.12)"/>
        <circle cx="80" cy="134" r="3.5" fill="#ffd000" filter="url(#gf)" style={{ animation:'pulse-glow 2s ease-in-out infinite' }}/>
        <circle cx="54" cy="156" r="3" fill="#ffd000" style={{ animation:'pulse-glow 2.5s infinite' }}/>
        <circle cx="63" cy="156" r="3" fill="#ffaa00" style={{ animation:'pulse-glow 2.5s infinite .5s' }}/>
        <circle cx="72" cy="156" r="3" fill="#ffe566" style={{ animation:'pulse-glow 2.5s infinite 1s' }}/>
        <rect x="88" y="152" width="22" height="6" rx="3" fill="rgba(255,208,0,.08)" stroke="rgba(255,208,0,.2)" strokeWidth=".5"/>
        <rect x="89" y="153" width="14" height="4" rx="2" fill="rgba(255,208,0,.4)"/>
        {/* NECK */}
        <rect x="66" y="84" width="28" height="18" rx="4" fill="#141000" stroke="rgba(255,208,0,.3)" strokeWidth="1"/>
        <line x1="72" y1="84" x2="72" y2="102" stroke="rgba(255,208,0,.2)" strokeWidth="1"/>
        <line x1="80" y1="84" x2="80" y2="102" stroke="rgba(255,208,0,.2)" strokeWidth="1"/>
        <line x1="88" y1="84" x2="88" y2="102" stroke="rgba(255,208,0,.2)" strokeWidth="1"/>
        {/* HEAD */}
        <g transform={`translate(80,52) rotate(${headRot}) translate(-80,-52)`}>
          <rect x="77" y="2" width="6" height="22" rx="3" fill="url(#ra)"/>
          <circle cx="80" cy="2" r="5" fill="#ffd000" filter="url(#gf)" style={{ animation:'pulse-glow 2s ease-in-out infinite' }}/>
          <circle cx="80" cy="2" r="9" fill="none" stroke="rgba(255,208,0,.28)" strokeWidth="1" style={{ animation:'pulse-glow 2s ease-in-out infinite' }}/>
          <rect x="42" y="22" width="76" height="64" rx="14" fill="url(#rh)" stroke="rgba(255,208,0,.28)" strokeWidth="1.5"/>
          <rect x="46" y="26" width="68" height="56" rx="10" fill="none" stroke="rgba(255,255,255,.03)" strokeWidth="1"/>
          <line x1="42" y1="50" x2="118" y2="50" stroke="rgba(255,208,0,.07)" strokeWidth="1"/>
          <rect x="43" y="22" width="74" height="2" rx="1" fill="rgba(255,208,0,.2)" clipPath="url(#hc)" style={{ animation:'scanline 2.6s linear infinite' }}/>
          <rect x="40" y="36" width="4" height="18" rx="2" fill="rgba(255,208,0,.15)" stroke="rgba(255,208,0,.2)" strokeWidth=".5"/>
          <rect x="116" y="36" width="4" height="18" rx="2" fill="rgba(255,208,0,.15)" stroke="rgba(255,208,0,.2)" strokeWidth=".5"/>
          <ellipse cx="63" cy="44" rx="12" ry="12" fill="#080700" stroke="rgba(255,208,0,.25)" strokeWidth="1"/>
          <ellipse cx="97" cy="44" rx="12" ry="12" fill="#080700" stroke="rgba(255,208,0,.25)" strokeWidth="1"/>
          <ellipse cx="63" cy="44" rx="10" ry="10" fill="none" stroke="rgba(255,208,0,.12)" strokeWidth="1.5"/>
          <ellipse cx="97" cy="44" rx="10" ry="10" fill="none" stroke="rgba(255,208,0,.12)" strokeWidth="1.5"/>
          <g transform={`translate(${eyeX},${eyeY})`}>
            <ellipse cx="63" cy="44" rx="7" ry={blink ? .7 : 7} fill="url(#re)" filter="url(#gf)" style={{ transition:'ry .07s' }}/>
            <ellipse cx="97" cy="44" rx="7" ry={blink ? .7 : 7} fill="url(#re)" filter="url(#gf)" style={{ transition:'ry .07s' }}/>
            <circle cx="64" cy="45" r="2.5" fill="rgba(10,8,0,.7)"/>
            <circle cx="98" cy="45" r="2.5" fill="rgba(10,8,0,.7)"/>
            <circle cx="61" cy="42" r="1.5" fill="rgba(255,255,200,.75)"/>
            <circle cx="95" cy="42" r="1.5" fill="rgba(255,255,200,.75)"/>
          </g>
          <path d={mp} stroke="rgba(255,208,0,.9)" strokeWidth="2.2" fill="none" strokeLinecap="round" style={{ transition:'d .28s ease', filter:'drop-shadow(0 0 3px rgba(255,208,0,.5))' }}/>
          <circle cx="50" cy="62" r="2.5" fill="#ffd000" style={{ animation:'pulse-glow 3s ease-in-out infinite' }}/>
          <circle cx="110" cy="62" r="2.5" fill="#ffaa00" style={{ animation:'pulse-glow 3s ease-in-out infinite 1.2s' }}/>
        </g>
        {/* WAIST */}
        <rect x="44" y="190" width="72" height="13" rx="6" fill="url(#rb)" stroke="rgba(255,208,0,.14)" strokeWidth="1"/>
        {/* LEFT LEG */}
        <g transform={`translate(61,203) rotate(${leftLegRot}) translate(-61,-203)`} style={{ transformOrigin:'61px 203px' }}>
          <rect x="46" y="200" width="30" height="52" rx="10" fill="url(#rb)" stroke="rgba(255,208,0,.14)" strokeWidth="1"/>
          <circle cx="61" cy="218" r="6" fill="#0d0b00" stroke="rgba(255,208,0,.28)" strokeWidth="1"/>
          <rect x="50" y="224" width="22" height="3" rx="1.5" fill="rgba(255,208,0,.1)"/>
          <rect x="40" y="248" width="42" height="11" rx="5.5" fill="url(#rb)" stroke="rgba(255,208,0,.18)" strokeWidth="1"/>
          <rect x="42" y="250" width="12" height="7" rx="3.5" fill="rgba(255,208,0,.14)"/>
        </g>
        {/* RIGHT LEG */}
        <g transform={`translate(99,203) rotate(${rightLegRot}) translate(-99,-203)`} style={{ transformOrigin:'99px 203px' }}>
          <rect x="84" y="200" width="30" height="52" rx="10" fill="url(#rb)" stroke="rgba(255,208,0,.14)" strokeWidth="1"/>
          <circle cx="99" cy="218" r="6" fill="#0d0b00" stroke="rgba(255,208,0,.28)" strokeWidth="1"/>
          <rect x="88" y="224" width="22" height="3" rx="1.5" fill="rgba(255,208,0,.1)"/>
          <rect x="78" y="248" width="42" height="11" rx="5.5" fill="url(#rb)" stroke="rgba(255,208,0,.18)" strokeWidth="1"/>
          <rect x="106" y="250" width="12" height="7" rx="3.5" fill="rgba(255,208,0,.14)"/>
        </g>
      </g>
      <ellipse cx="80" cy={268 - (jumping ? 2 : 0)} rx={jumping ? 18 : 28} ry={jumping ? 3 : 5}
        fill="rgba(255,208,0,.15)" style={{ animation:'shadowPulse 1.2s ease-in-out infinite' }}/>
    </svg>
  );
};

export default AnimatedRobot;
