import { useState, useEffect, useRef } from 'react';

import GlobalStyles from './components/GlobalStyles.jsx';
import Cursor from './components/Cursor.jsx';
import RoamingRobot from './components/RoamingRobot.jsx';
import Nav from './components/Nav.jsx';

import Hero from './sections/Hero.jsx';
import About from './sections/About.jsx';
import BuildingInPublic from './sections/BuildingInPublic.jsx';
import SkillsConstellation from './sections/SkillsConstellation.jsx';
import { EngineeringMindset, Technologies, Metrics, Philosophy } from './sections/Misc.jsx';
import Contact from './sections/Contact.jsx';

const Footer = () => (
  <footer style={{ padding:'40px', borderTop:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:16 }}>
    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
      <div style={{ width:6, height:6, borderRadius:'50%', background:'var(--accent)', animation:'pulse-glow 2s infinite' }}/>
      <span className="syne" style={{ fontSize:14, fontWeight:700 }}>Kartik Gaikwad</span>
    </div>
    <span className="mono" style={{ fontSize:10, color:'var(--text3)', letterSpacing:'.1em' }}>MAHARASHTRA, INDIA · BUILDING THE FUTURE</span>
    <span className="mono" style={{ fontSize:10, color:'var(--text3)', letterSpacing:'.1em' }}>© 2025 · ALL RIGHTS RESERVED</span>
  </footer>
);

export default function App() {
  const mouseX = useRef(window.innerWidth / 2);
  const mouseY = useRef(window.innerHeight / 2);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onM = e => { mouseX.current = e.clientX; mouseY.current = e.clientY; };
    const onS = () => setScrolled(window.scrollY > 50);
    window.addEventListener('mousemove', onM);
    window.addEventListener('scroll', onS, { passive: true });
    return () => { window.removeEventListener('mousemove', onM); window.removeEventListener('scroll', onS); };
  }, []);

  useEffect(() => {
    const obs = new IntersectionObserver(
      entries => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: .1, rootMargin: '0px 0px -60px 0px' }
    );
    const t = setTimeout(() => {
      document.querySelectorAll('.reveal-on-scroll').forEach(el => obs.observe(el));
    }, 200);
    return () => { clearTimeout(t); obs.disconnect(); };
  }, []);

  return (
    <>
      <GlobalStyles />
      <Cursor />
      <RoamingRobot mouseX={mouseX} mouseY={mouseY} />
      <Nav scrolled={scrolled} />
      <main>
        <Hero mouseX={mouseX} mouseY={mouseY} />
        <About />
        <BuildingInPublic />
        <SkillsConstellation />
        <EngineeringMindset />
        <Technologies />
        <Metrics />
        <Philosophy />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
